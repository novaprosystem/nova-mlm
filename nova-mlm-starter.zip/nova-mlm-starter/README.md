# Nova MLM Starter

Backend (Express + Prisma + Postgres) + Frontend (Next.js)
